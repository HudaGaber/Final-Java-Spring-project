package com.example.finalSpringProject.finalSpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalSpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
